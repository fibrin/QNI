To compile a DLL that can be used under Matlab, type 
   "ezmexmggvf('-a')"
on the Matlab commandline. 