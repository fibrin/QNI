compile = 'mggvf.c';
if strcmp(computer, 'PCWIN')
   build = 'mggvf.c';
else
   build = 'mggvf.c';
end
